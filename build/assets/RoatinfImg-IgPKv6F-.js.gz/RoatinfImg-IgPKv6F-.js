import{j as t}from"./react-vendor-CU6lFo1N.js";import"./animation-vendor-DE7fCS50.js";import"./vendor-DnuN4cIi.js";import"./query-vendor-B8s5OfyV.js";import"./ui-vendor-BNgsC25r.js";import"./swiper-vendor-CoL_RVtK.js";import"./date-vendor-BpmxrJb6.js";const c=({position:i="lg:w-auto w-[10em]",src:a="/images/HomepageImages/RoundPatternSection2.svg",divClass:e="absolute "})=>t.jsx("div",{className:`${e} ${i} `,children:t.jsx("img",{src:a,alt:"Background Pattern",className:`    w-full h-full object-contain
      origin-center
      animate-[spin_18s_linear_infinite]
      [will-change:transform]  `})});export{c as default};
